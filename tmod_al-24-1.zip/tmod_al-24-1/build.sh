#!/bin/bash

docker build -t tmodloader:al.24.1 .